﻿using System.Collections;
using UnityEngine;
using System.Collections.Generic;
/*public class characterController: MonoBehaviour
{

    public float lookSpeed = 10;
    private Vector3 curLoc;
    private Vector3 prevLoc;

    void Update()
    {
        InputListen();
        transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.RotateTowards(transform.position - prevLoc), Time.fixedDeltaTime * lookSpeed,90);
    }

    private void InputListen()
    {
        prevLoc = curLoc;
        curLoc = transform.position;

        if (Input.GetKey(KeyCode.LeftArrow))
            curLoc.x -= 1 * Time.fixedDeltaTime;
        if (Input.GetKey(KeyCode.RightArrow))
            curLoc.x += 1 * Time.fixedDeltaTime;
        if (Input.GetKey(KeyCode.UpArrow))
            curLoc.z += 1 * Time.fixedDeltaTime;
        if (Input.GetKey(KeyCode.DownArrow))
            curLoc.z -= 1 * Time.fixedDeltaTime;

        transform.position = curLoc;

    }
}*/

public class characterController : MonoBehaviour
{
    bool arrowsUp = true;
    bool arrowsDown = true;
    bool arrowsLeft = true;
    bool arrowsRight = true;
    public List<GameObject> Snake = new List<GameObject>();
    public char movement = 'd';
    private Vector3 Pos;

    void input() {
        float translation = Input.GetAxis("Vertical") * 5;
        if (Input.GetKey(KeyCode.UpArrow))
        {
            if (arrowsUp == true) {
                movement = 'w';
                transform.Rotate(translation, 90, 0);
                arrowsLeft = true;
                arrowsRight = true;
            }
            arrowsDown = false;
            arrowsUp = false;
        }
        if (Input.GetKey(KeyCode.DownArrow))
        {
            if (arrowsDown == true)
            {
                movement = 's';
                transform.Rotate(translation, -90, 0);
                arrowsLeft = true;
                arrowsRight = true;
            }
            arrowsDown = false;
            arrowsUp = false;
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            if (arrowsRight == true)
            {
                movement = 'd';
                transform.Rotate(translation, -90, 0);
                arrowsUp = true;
                arrowsDown= true;
            }
            arrowsLeft = false;
            arrowsRight = false;
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            if (arrowsLeft == true)
            {
                movement = 'a';
                transform.Rotate(translation, -90, 0);
                arrowsUp = true;
                arrowsDown = true;
            }
            arrowsLeft = false;
            arrowsRight = false;
        }
    }
    void append() {
        GameObject part = Instantiate(Resources.Load<GameObject>("part") as GameObject);
        if (!Snake.Contains(part))
            Snake.Add(part);
    }
    void move() {

        for (int j = Snake.Count - 1; j > 0; j--)
        {
            if (j > 0)
                Snake[j].transform.position = Snake[j - 1].transform.position;
        }
        Snake[0].transform.position = transform.position;
        switch (movement) {
            case 'w':
                Pos.x++;
                break;
            case 's':
                Pos.x--;
                break;
            case 'd':
                Pos.z--;
                break;
            case 'a':
                Pos.z++;
                break;
        }
       
        transform.position = Pos;

    }

    void Start() {
        for (int i = 0; i < 100; i++) {
            append();
        }
    }

    void Update() {
        input();
        move();
    }
    
  /*  public float moveSpeed;
    private Rigidbody myRigidBody;
    // Use this for initialization
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked; //turn off cursor don't see mouse
        myRigidBody = GetComponent<Rigidbody>();
        moveSpeed = 100;
    }

    // Update is called once per frame
    void Update()
    {
        float translation = Input.GetAxis("Vertical") * moveSpeed;
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            transform.Rotate(translation, -90, 0);
            moveSpeed = -10;
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.Rotate(translation, 90, 0);
            moveSpeed = 10;
        }
        myRigidBody.velocity = new Vector3(moveSpeed, 0);

    }*/
}

