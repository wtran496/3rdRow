﻿using System.Collections;
using UnityEngine;
using System.Collections.Generic;

public class characterController : MonoBehaviour
{
    public List<GameObject> Snake = new List<GameObject>();
    public char movement = 'd';
    private Vector3 Pos;
    int dir = 2;
    bool transition = false, R = true, L = false;
   float translation = Input.GetAxis("Vertical");
    int rotate = 0;
    void input() {
        

        if (Input.GetKeyUp(KeyCode.RightArrow))
        {
            movement = 'd';
           
           
            if (L)
                transition = true;
            else
                transition = false;
            if (rotate % 3 != 2)
             transform.Rotate(translation, 90, 0);
            else
             transform.Rotate(translation, -90, 0);
            R = true;
            L = false;
            rotate++;
            dir++;
        }
        if (Input.GetKeyUp(KeyCode.LeftArrow))
        {
            movement = 'a';
           transform.Rotate(translation, -90, 0);
            if (R)
                transition = true;
            else
                transition = false;
            L = true;
            R = false;
            dir++;
        }
    }
    void append() {
        GameObject part = Instantiate(Resources.Load<GameObject>("part") as GameObject);
        if (!Snake.Contains(part))
            Snake.Add(part);
    }
    void move() {//need a parameter to allow position

        for (int j = Snake.Count - 1; j > 0; j--)
        {
            if (j > 0)
                Snake[j].transform.position = Snake[j - 1].transform.position;
        }
        Snake[0].transform.position = transform.position;
        switch (movement)
        {
            case 'd':          
                if (dir % 2 == 0 && transition == true)//up
                    Pos.z++;
                else if (dir % 2 == 0 && R == true)  // down
                    Pos.z--;
                else if (dir % 2 == 1)//left
                    Pos.x++;
                break;
            case 'a':
                if (dir % 2 == 0 && transition == true)//up
                    Pos.z++;
                else if (dir % 2 == 0 && L == true)  // down
                    Pos.z--;
                else if (dir % 2 == 1)//left/right
                    Pos.x--;
                break;
        }

        transform.position = Pos;

    }

    void Start() {
        for (int i = 0; i < 10; i++) {
            append();
        }
        

    }

    void Update() {
        input();
        move();
        //transform.LookAt(Pos);
    }
    
  /*  public float moveSpeed;
    private Rigidbody myRigidBody;
    // Use this for initialization
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked; //turn off cursor don't see mouse
        myRigidBody = GetComponent<Rigidbody>();
        moveSpeed = 100;
    }

    // Update is called once per frame
    void Update()
    {
        float translation = Input.GetAxis("Vertical") * moveSpeed;
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            transform.Rotate(translation, -90, 0);
            moveSpeed = -10;
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.Rotate(translation, 90, 0);
            moveSpeed = 10;
        }
        myRigidBody.velocity = new Vector3(moveSpeed, 0);

    }*/
}

