﻿using System.Collections;
using UnityEngine;

public class DestroyCollision : MonoBehaviour {

    private void OnCollisionEnter(Collision other) {
        if (other.gameObject.tag == "Player") {
            Destroy(gameObject);
            Debug.Log("Collide");
        }
    }
}
