﻿using System.Collections;
using UnityEngine;

public class DestroyPlayer : MonoBehaviour
{
    public GameObject enemy;
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Enemy")
        Destroy(this.gameObject);
    }
}