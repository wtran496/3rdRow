﻿using System.Collections;
using UnityEngine;

public class DestroyCollision : MonoBehaviour {

    public GameObject food;
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Food")
            Destroy(other.gameObject);
    }
}
