﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SnakeHead : MonoBehaviour {

    public SnakeMovement movement;

    public SpawnObject SQ;

	void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.tag == "Food")
        {
            movement.AddBodyPart();

            Destroy(col.gameObject);

            // spawn food
            SQ.SpawnFood();
        }
        else
        {
            if (col.transform != movement.BodyParts[1] && !movement.IsAlive)
            {
                if (Time.time - movement.TimeFromLastRetry > 5)
                    movement.DIE();
            }
        }
    }
}
